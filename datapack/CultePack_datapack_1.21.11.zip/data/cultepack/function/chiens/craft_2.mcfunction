recipe take @s cultepack:chien_up_2
advancement revoke @s only cultepack:chien_up_2
give @s popped_chorus_fruit[custom_name=[{text:'Amélioration Chien',italic:false,color:blue},{text:' '},{text:'[lvl-2]',color:light_purple}],lore=[[{text:'Offre à ton chien :',italic:false,color:dark_aqua},{text:'',italic:false,color:dark_purple}],[{text:' +2 attaque',italic:false,color:gold},{text:'',italic:false,color:dark_purple}],[{text:' ',italic:false,color:dark_purple},{text:'+5 vie',color:gold}]],custom_model_data={strings:[chien_2]},custom_data={Tags:chien_2}]
clear @s knowledge_book