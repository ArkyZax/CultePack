effect clear @s poison
 